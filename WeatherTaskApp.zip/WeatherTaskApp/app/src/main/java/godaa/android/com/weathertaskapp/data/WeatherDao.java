package godaa.android.com.weathertaskapp.data;

public class WeatherDao {
}
